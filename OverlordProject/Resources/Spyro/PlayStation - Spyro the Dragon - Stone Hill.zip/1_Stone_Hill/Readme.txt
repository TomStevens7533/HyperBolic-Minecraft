Model extracted from the original games using the SpyroWorldViewer by Kly_Men_COmpany, adapted with blender and some python scripts by Pierre Geissler.

-------- Folder content:

- *M.dae: Textured model of the level with its vertex color lightmap
- *S.dae: Skybox, vertex colors only

Use the two provided shaders to render these models with their original appearance in Unity

